import FWCore.ParameterSet.Config as cms

process = cms.Process("VBFDiPhoDiJetMVATraining")

process.source = cms.Source("PoolSource",
    fileNames = cms.untracked.vstring('root://xrootd-cms.infn.it//store/group/phys_higgs/cmshgg/ferriff/flashgg/RunIISpring16DR80X-2_2_0-25ns_ICHEP16_MiniAODv2/2_2_0/GJet_Pt-40toInf_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring16DR80X-2_2_0-25ns_ICHEP16_MiniAODv2-2_2_0-v0-RunIISpring16MiniAODv2-PUSpring16_80X_mcRun2_asymptotic_2016_miniAODv2_v0-v1/160707_143944/0000/myMicroAODOutputFile_1.root')
)
process.VBFDiPhoDiJetMVATrainingDumpConfNew = cms.PSet(
    categories = cms.VPSet(),
    className = cms.untracked.string('CutBasedVBFDiPhoDiJetMVAResultDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet()
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(True),
    dumpTrees = cms.untracked.bool(False),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(),
        puBins = cms.vdouble(),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(False),
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    lumiWeight = cms.double(42.9696969697),
    maxCandPerEvent = cms.int32(1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$LABEL_$SUBCAT'),
    processId = cms.string('gamJet'),
    quietRooFit = cms.untracked.bool(False),
    src = cms.InputTag("flashggVBFDiPhoDiJetMVANew"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)

process.VBFMVATrainingDumpConfNew = cms.PSet(
    categories = cms.VPSet(),
    className = cms.untracked.string('CutBasedVBFMVAResultDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet()
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(True),
    dumpTrees = cms.untracked.bool(False),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(),
        puBins = cms.vdouble(),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(False),
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    lumiWeight = cms.double(42.9696969697),
    maxCandPerEvent = cms.int32(1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$LABEL_$SUBCAT'),
    processId = cms.string('gamJet'),
    quietRooFit = cms.untracked.bool(False),
    src = cms.InputTag("flashggVBFMVANew"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)

process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(198000)
)

process.flashggDiPhotonMVA = cms.EDProducer("FlashggDiPhotonMVAProducer",
    BeamSpotSigma = cms.double(3.7),
    BeamSpotTag = cms.InputTag("offlineBeamSpot"),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    Version = cms.string('new'),
    VertexProbParamsConv = cms.vdouble(-0.045, -0.148, -0.328, -0.184),
    VertexProbParamsNoConv = cms.vdouble(-0.366, -0.126, -0.119, -0.091),
    diphotonMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_DiPhoton_ICHEP.weights.xml'),
    doSigmaMdecorr = cms.bool(True),
    sigmaMdecorrFile = cms.FileInPath('flashgg/Taggers/data/diphoMVA_sigmaMoMdecorr_split_Mgg40_180.root')
)


process.flashggSigmaMoMpToMTag = cms.EDProducer("FlashggSigmaMpTTagProducer",
    BoundariesSigmaMoM = cms.vdouble(0.0, 0.00764, 0.0109, 0.0288),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireScaledPtCuts = cms.bool(True),
    SystLabel = cms.string('')
)


process.flashggTHQLeptonicTag = cms.EDProducer("FlashggTHQLeptonicTagProducer",
    DeltaRTrkElec = cms.untracked.double(1.0),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.untracked.double(0.2),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.untracked.double(-1.0),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PhoMVAThreshold = cms.untracked.double(-0.9),
    PuIDCutoffThreshold = cms.untracked.double(0.8),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.untracked.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    Zmass_ = cms.untracked.double(91.9),
    bDiscriminator = cms.untracked.vdouble(0.605, 0.89),
    bTag = cms.untracked.string('pfCombinedInclusiveSecondaryVertexV2BJetTags'),
    bjetsNumberThreshold = cms.untracked.double(1.0),
    deltaMassElectronZThreshold_ = cms.untracked.double(10.0),
    deltaRJetLeadPhoThreshold = cms.untracked.double(0.4),
    deltaRJetLepThreshold = cms.untracked.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.untracked.double(0.4),
    deltaRLepPhoThreshold = cms.untracked.double(0.5),
    deltaRPhoElectronThreshold = cms.untracked.double(1.0),
    electronEtaCuts = cms.untracked.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.untracked.double(0.15),
    electronNumOfHitsThreshold = cms.untracked.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.untracked.double(4.7),
    jetPtThreshold = cms.untracked.double(25.0),
    jetsNumberThreshold = cms.untracked.double(2.0),
    leadPhoOverMassThreshold = cms.untracked.double(0.5),
    leptonEtaThreshold = cms.untracked.double(2.4),
    leptonPtThreshold = cms.untracked.double(20),
    muPFIsoSumRelThreshold = cms.untracked.double(0.25),
    nonTrigMVAEtaCuts = cms.untracked.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.untracked.vdouble(0.913286, 0.805013, 0.358969),
    subleadPhoOverMassThreshold = cms.untracked.double(0.25)
)


process.flashggTTHHadronicTag = cms.EDProducer("FlashggTTHHadronicTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.double(0.2),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.5),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PhoMVAThreshold = cms.double(-0.9),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.46, 0.8),
    bTag = cms.string('pfCombinedInclusiveSecondaryVertexV2BJetTags'),
    bjetsNumberThreshold = cms.int32(1),
    dRJetPhoLeadCut = cms.double(0.4),
    dRJetPhoSubleadCut = cms.double(0.4),
    elMiniIsoEBThreshold = cms.double(0.045),
    elMiniIsoEEThreshold = cms.double(0.08),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.int32(5),
    leadPhoOverMassThreshold = cms.double(0.5),
    leadPhoPtThreshold = cms.double(20),
    leadPhoUseVariableThreshold = cms.bool(True),
    leptonPtThreshold = cms.double(20),
    muMiniIsoSumRelThreshold = cms.double(0.05),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    subleadPhoOverMassThreshold = cms.double(0.25),
    subleadPhoPtThreshold = cms.double(20),
    subleadPhoUseVariableThreshold = cms.bool(True),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useStdLeptonID = cms.bool(True)
)


process.flashggTTHLeptonicTag = cms.EDProducer("FlashggTTHLeptonicTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.double(0.2),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(-0.4),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.46, 0.8),
    bTag = cms.string('pfCombinedInclusiveSecondaryVertexV2BJetTags'),
    bjetsNumberThreshold = cms.double(1.0),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetLeadPhoThreshold = cms.double(0.4),
    deltaRJetLepThreshold = cms.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.double(0.4),
    deltaRMuonPhoThreshold = cms.double(0.4),
    deltaRPhoElectronThreshold = cms.double(0.4),
    elMiniIsoEBThreshold = cms.double(0.045),
    elMiniIsoEEThreshold = cms.double(0.08),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(2.0),
    leadPhoOverMassThreshold = cms.double(0.5),
    leptonPtThreshold = cms.double(20),
    muMiniIsoSumRelThreshold = cms.double(0.05),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useStdLeptonID = cms.bool(True)
)


process.flashggTagSorter = cms.EDProducer("FlashggTagSorter",
    BlindedSelectionPrintout = cms.bool(False),
    Debug = cms.untracked.bool(False),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    MassCutLower = cms.double(100),
    MassCutUpper = cms.double(180.0),
    MaxObjectWeightException = cms.double(10.0),
    MaxObjectWeightWarning = cms.double(2.0),
    MinObjectWeightException = cms.double(0.1),
    MinObjectWeightWarning = cms.double(0.5),
    StoreOtherTagInfo = cms.bool(False),
    TagPriorityRanges = cms.VPSet(cms.PSet(
        TagName = cms.InputTag("flashggTHQLeptonicTag")
    ), 
        cms.PSet(
            TagName = cms.InputTag("flashggTTHLeptonicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggTTHHadronicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggVBFTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggUntagged")
        ))
)


process.flashggUnpackedJets = cms.EDProducer("FlashggVectorVectorJetUnpacker",
    JetsTag = cms.InputTag("flashggFinalJets"),
    NCollections = cms.uint32(8)
)


process.flashggUntagged = cms.EDProducer("FlashggUntaggedTagProducer",
    Boundaries = cms.vdouble(-0.398, 0.308, 0.624, 0.907),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireScaledPtCuts = cms.bool(True),
    SystLabel = cms.string('')
)


process.flashggUpdatedIdMVADiPhotons = cms.EDProducer("FlashggDiPhotonWithUpdatedPhoIdMVAProducer",
    Debug = cms.bool(False),
    correctionFile = cms.FileInPath('flashgg/MicroAOD/data/transformation_80X_v4.root'),
    photonIdMVAweightfile_EB = cms.FileInPath('flashgg/MicroAOD/data/MVAweights_80X_barrel_ICHEPvtx.xml'),
    photonIdMVAweightfile_EE = cms.FileInPath('flashgg/MicroAOD/data/MVAweights_80X_endcap_ICHEPvtx.xml'),
    rhoFixedGridCollection = cms.InputTag("fixedGridRhoAll"),
    src = cms.InputTag("flashggDiPhotons")
)


process.flashggVBFDiPhoDiJetMVA = cms.EDProducer("FlashggVBFDiPhoDiJetMVAProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    UseLegacyMVA = cms.bool(False),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA"),
    vbfDiPhoDiJetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_classification_combined-mva-80x-ICHEP-v01_BDTG.weights.xml')
)


process.flashggVBFMVA = cms.EDProducer("FlashggVBFMVAProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    JetIDLevel = cms.string('Loose'),
    MVAMethod = cms.string('BDT'),
    MinDijetMinv = cms.double(0.0),
    UseJetID = cms.bool(True),
    UsePuJetID = cms.bool(False),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    merge3rdJet = cms.bool(False),
    pujidWpPtBin1 = cms.vdouble(),
    pujidWpPtBin2 = cms.vdouble(),
    pujidWpPtBin3 = cms.vdouble(),
    rmsforwardCut = cms.double(0.03),
    thirdJetDRCut = cms.double(1.8),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_classification_dijet-mva-80x-ICHEP-v04.weights.xml')
)


process.flashggVBFTag = cms.EDProducer("FlashggVBFTagProducer",
    Boundaries = cms.vdouble(0.634, 0.919),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    DropNonGoldData = cms.bool(False),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    GetQCDWeights = cms.bool(False),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireVBFPreselection = cms.bool(True),
    SetArbitraryNonGoldMC = cms.bool(False),
    SystLabel = cms.string(''),
    VBFDiPhoDiJetMVAResultTag = cms.InputTag("flashggVBFDiPhoDiJetMVA"),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA")
)


process.flashggVHEtTag = cms.EDProducer("FlashggVHEtTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMets"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    dPhiDiphotonMetThreshold = cms.double(2.1),
    diphoMVAThreshold = cms.double(-1.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    metPtThreshold = cms.double(70),
    phoIdMVAThreshold = cms.double(-0.9),
    subleadPhoOverMassThreshold = cms.double(0.25)
)


process.flashggVHHadronicTag = cms.EDProducer("FlashggVHHadronicTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    cosThetaStarThreshold = cms.double(0.5),
    dRJetToPhoLThreshold = cms.double(0.5),
    dRJetToPhoSThreshold = cms.double(0.5),
    dijetMassHighThreshold = cms.double(120.0),
    dijetMassLowThreshold = cms.double(60.0),
    diphoMVAThreshold = cms.double(-1.0),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(40.0),
    jetsNumberThreshold = cms.double(2.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    phoIdMVAThreshold = cms.double(-0.9),
    subleadPhoOverMassThreshold = cms.double(0.25)
)


process.flashggVHLooseTag = cms.EDProducer("FlashggVHLooseTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronPtThreshold = cms.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.187),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetMuonThreshold = cms.double(0.5),
    deltaRMuonPhoThreshold = cms.double(0.5),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.5),
    deltaRPhoSubLeadJet = cms.double(0.5),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False)
)


process.flashggVHTightTag = cms.EDProducer("FlashggVHTightTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronPtThreshold = cms.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.187),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetElectronThreshold = cms.double(0.5),
    deltaRJetMuonThreshold = cms.double(0.5),
    deltaRLowPtMuonPhoThreshold = cms.double(0.5),
    deltaRMuonPhoThreshold = cms.double(1),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.5),
    deltaRPhoSubLeadJet = cms.double(0.5),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    invMassLepHighThreshold = cms.double(110.0),
    invMassLepLowThreshold = cms.double(70.0),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonLowPtThreshold = cms.double(10.0),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    numberOfHighPtMuonsThreshold = cms.double(1.0),
    numberOfLowPtMuonsThreshold = cms.double(2.0),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False)
)


process.flashggZPlusJetTag = cms.EDProducer("FlashggZPlusJetTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7"))
)


process.flashggPreselectedDiPhotons = cms.EDFilter("GenericDiPhotonCandidateSelector",
    categories = cms.VPSet(cms.PSet(
        cut = cms.string('isEB && full5x5_r9>0.85'),
        selection = cms.VPSet(cms.PSet(
            max = cms.string('100000.0'),
            rhocorr = cms.PSet(
                bins = cms.vdouble(0.0, 0.9, 1.5, 2, 2.2, 
                    3),
                vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                var = cms.string('abs(superCluster.eta)')
            )
        ), 
            cms.PSet(
                max = cms.string('100000.0')
            ), 
            cms.PSet(
                max = cms.string('100000.0')
            ), 
            cms.PSet(
                min = cms.string('0.5')
            ), 
            cms.PSet(
                min = cms.string('0.5')
            ))
    ), 
        cms.PSet(
            cut = cms.string('isEE && full5x5_r9>0.90'),
            selection = cms.VPSet(cms.PSet(
                max = cms.string('100000.0'),
                rhocorr = cms.PSet(
                    bins = cms.vdouble(0.0, 0.9, 1.5, 2, 2.2, 
                        3),
                    vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                    var = cms.string('abs(superCluster.eta)')
                )
            ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    min = cms.string('0.8')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                ))
        ), 
        cms.PSet(
            cut = cms.string('isEB && full5x5_r9<=0.85'),
            selection = cms.VPSet(cms.PSet(
                max = cms.string('4.0'),
                rhocorr = cms.PSet(
                    bins = cms.vdouble(0.0, 0.9, 1.5, 2, 2.2, 
                        3),
                    vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                    var = cms.string('abs(superCluster.eta)')
                )
            ), 
                cms.PSet(
                    max = cms.string('6.0')
                ), 
                cms.PSet(
                    max = cms.string('0.015')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                ))
        ), 
        cms.PSet(
            cut = cms.string('isEE && full5x5_r9<=0.90'),
            selection = cms.VPSet(cms.PSet(
                max = cms.string('4.0'),
                rhocorr = cms.PSet(
                    bins = cms.vdouble(0.0, 0.9, 1.5, 2, 2.2, 
                        3),
                    vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                    var = cms.string('abs(superCluster.eta)')
                )
            ), 
                cms.PSet(
                    max = cms.string('6.0')
                ), 
                cms.PSet(
                    max = cms.string('0.035')
                ), 
                cms.PSet(
                    min = cms.string('0.8')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                ))
        )),
    cut = cms.string('    (leadingPhoton.full5x5_r9>0.8||leadingPhoton.egChargedHadronIso<20||leadingPhoton.egChargedHadronIso/leadingPhoton.pt<0.3) && (subLeadingPhoton.full5x5_r9>0.8||subLeadingPhoton.egChargedHadronIso<20||subLeadingPhoton.egChargedHadronIso/subLeadingPhoton.pt<0.3) && (leadingPhoton.hadronicOverEm < 0.08 && subLeadingPhoton.hadronicOverEm < 0.08) && (leadingPhoton.pt >30.0 && subLeadingPhoton.pt > 20.0) && (abs(leadingPhoton.superCluster.eta) < 2.5 && abs(subLeadingPhoton.superCluster.eta) < 2.5) && (abs(leadingPhoton.superCluster.eta) < 1.4442 || abs(leadingPhoton.superCluster.eta) > 1.566) && (abs(subLeadingPhoton.superCluster.eta) < 1.4442 || abs(subLeadingPhoton.superCluster.eta) > 1.566) && (leadPhotonId > -0.9 && subLeadPhotonId > -0.9)'),
    rho = cms.InputTag("fixedGridRhoAll"),
    src = cms.InputTag("flashggUpdatedIdMVADiPhotons"),
    variables = cms.vstring('pfPhoIso03', 
        'trkSumPtHollowConeDR03', 
        'full5x5_sigmaIetaIeta', 
        'full5x5_r9', 
        'passElectronVeto')
)


process.VBFDiPhoDiJetMVADumperNew = cms.EDAnalyzer("CutBasedVBFDiPhoDiJetMVAResultDumper",
    categories = cms.VPSet(cms.PSet(
        histograms = cms.VPSet(cms.PSet(
            name = cms.untracked.string('VBFDiPhoDiJetMVAResult'),
            nxbins = cms.untracked.int32(100),
            x = cms.untracked.string('VBFDiPhoDiJetMVAResult'),
            xmax = cms.untracked.double(1.0),
            xmin = cms.untracked.double(-1.0)
        )),
        label = cms.string('All'),
        subcats = cms.int32(0),
        variables = cms.VPSet(cms.PSet(
            expr = cms.string('dijet_mva'),
            name = cms.untracked.string('dijet_mva')
        ), 
            cms.PSet(
                expr = cms.string('dipho_mva'),
                name = cms.untracked.string('dipho_mva')
            ), 
            cms.PSet(
                expr = cms.string('dipho_PToM'),
                name = cms.untracked.string('dipho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('vbfDiPhoDiJetMvaResult'),
                name = cms.untracked.string('vbfDiPhoDiJetMvaResult')
            ))
    )),
    className = cms.untracked.string('CutBasedVBFDiPhoDiJetMVAResultDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet(cms.PSet(
            cut = cms.string('dipho_PToM>=0'),
            name = cms.untracked.string('All')
        ))
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(True),
    dumpTrees = cms.untracked.bool(True),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(),
        puBins = cms.vdouble(),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(False),
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    lumiWeight = cms.double(42.9696969697),
    maxCandPerEvent = cms.int32(1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$LABEL_$SUBCAT'),
    processId = cms.string('gamJet'),
    quietRooFit = cms.untracked.bool(True),
    src = cms.InputTag("flashggVBFDiPhoDiJetMVANew"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)


process.VBFMVADumperNew = cms.EDAnalyzer("CutBasedVBFMVAResultDumper",
    categories = cms.VPSet(cms.PSet(
        histograms = cms.VPSet(cms.PSet(
            name = cms.untracked.string('VBFMVAValue'),
            nxbins = cms.untracked.int32(100),
            x = cms.untracked.string('vbfMvaResult_value'),
            xmax = cms.untracked.double(1.0),
            xmin = cms.untracked.double(-1.0)
        )),
        label = cms.string('All'),
        subcats = cms.int32(0),
        variables = cms.VPSet(cms.PSet(
            expr = cms.string('dijet_abs_dEta'),
            name = cms.untracked.string('dijet_abs_dEta')
        ), 
            cms.PSet(
                expr = cms.string('dijet_leadEta'),
                name = cms.untracked.string('dijet_leadEta')
            ), 
            cms.PSet(
                expr = cms.string('dijet_subleadEta'),
                name = cms.untracked.string('dijet_subleadEta')
            ), 
            cms.PSet(
                expr = cms.string('dijet_LeadJPt'),
                name = cms.untracked.string('dijet_LeadJPt')
            ), 
            cms.PSet(
                expr = cms.string('dijet_SubJPt'),
                name = cms.untracked.string('dijet_SubJPt')
            ), 
            cms.PSet(
                expr = cms.string('dijet_Zep'),
                name = cms.untracked.string('dijet_Zep')
            ), 
            cms.PSet(
                expr = cms.string('dijet_Mjj'),
                name = cms.untracked.string('dijet_Mjj')
            ), 
            cms.PSet(
                expr = cms.string('dipho_PToM'),
                name = cms.untracked.string('dipho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('leadPho_PToM'),
                name = cms.untracked.string('leadPho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('sublPho_PToM'),
                name = cms.untracked.string('sublPho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('dijet_dPhi_trunc'),
                name = cms.untracked.string('dijet_dPhi_trunc')
            ), 
            cms.PSet(
                expr = cms.string('vbfMvaResult_value'),
                name = cms.untracked.string('vbfMvaResult_value')
            ))
    )),
    className = cms.untracked.string('CutBasedVBFMVAResultDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet(cms.PSet(
            cut = cms.string('dipho_PToM>=0'),
            name = cms.untracked.string('All')
        ))
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(True),
    dumpTrees = cms.untracked.bool(True),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(),
        puBins = cms.vdouble(),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(False),
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    lumiWeight = cms.double(42.9696969697),
    maxCandPerEvent = cms.int32(1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$LABEL_$SUBCAT'),
    processId = cms.string('gamJet'),
    quietRooFit = cms.untracked.bool(True),
    src = cms.InputTag("flashggVBFMVANew"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)


process.flashggTagTester = cms.EDAnalyzer("FlashggTagTestAnalyzer",
    TagSorter = cms.InputTag("flashggTagSorter")
)


process.out = cms.OutputModule("PoolOutputModule",
    fileName = cms.untracked.string('/afs/cern.ch/work/g/gkrintir/private/CMSSW_8_0_10/src/flashgg/Taggers/test/MVATHQTraining/test_diphodijet_training/output_GJet_Pt-40toInf_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8_numEvent1000.root'),
    outputCommands = cms.untracked.vstring('drop *', 
        'keep *_flashgg*_*_*', 
        'drop *_flashggVertexMap*_*_*', 
        'drop *_flashggPuppi*_*_*', 
        'drop *_flashggPhotons_*_*', 
        'drop patPackedCandidates_*_*_*', 
        'drop *_flashggPrunedGenParticles_*_*', 
        'keep recoGenParticles_flashggPrunedGenParticles_*_*', 
        'keep recoVertexs_offlineSlimmedPrimaryVertices_*_*', 
        'keep *_reducedEgamma_reducedSuperClusters_*', 
        'keep *_reducedEgamma_*PhotonCores_*', 
        'keep *_*Rho*_*_*', 
        'keep *_offlineBeamSpot_*_*', 
        'keep *_TriggerResults_*_*', 
        'keep *_eventCount_*_*', 
        'keep *CaloClusters_*_*_*', 
        'keep *_weightsCount_*_*', 
        'keep *_generator_*_*', 
        'keep *_slimmedGenJets_*_*', 
        'keep *_flashggDiPhotons_*_*', 
        'keep *_slimmedAddPileupInfo_*_*', 
        'keep *GsfElectronCore*_*_*_*', 
        'keep *_flashggSelected*_*_*', 
        'drop *_flashgg*Jet*_*_*', 
        'drop *_flashggMuons_*_*', 
        'drop *_flashggElectrons_*_*', 
        'keep *_flashggFinalJets_*_*', 
        'keep *_flashggFinalPuppiJets_*_*', 
        'drop floatedmValueMap_electronMVAValueMapProducer_*_*', 
        'drop intedmValueMap_electronMVAValueMapProducer_*_*', 
        'keep *_selectedPatTrigger_*_*', 
        'keep *_flashgg*_*_*')
)


process.flashggTagSequence = cms.Sequence(process.flashggUpdatedIdMVADiPhotons+process.flashggPreselectedDiPhotons+process.flashggDiPhotonMVA+process.flashggUnpackedJets+process.flashggVBFMVA+process.flashggVBFDiPhoDiJetMVA+process.flashggUntagged+process.flashggVBFTag+process.flashggTTHLeptonicTag+process.flashggTTHHadronicTag+process.flashggTHQLeptonicTag+process.flashggTagSorter)


process.MessageLogger = cms.Service("MessageLogger",
    FrameworkJobReport = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        optionalPSet = cms.untracked.bool(True)
    ),
    categories = cms.untracked.vstring('FwkJob', 
        'FwkReport', 
        'FwkSummary', 
        'Root_NoDictionary'),
    cerr = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        FwkReport = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1)
        ),
        FwkSummary = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1)
        ),
        INFO = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000)
        ),
        noTimeStamps = cms.untracked.bool(False),
        optionalPSet = cms.untracked.bool(True),
        threshold = cms.untracked.string('INFO')
    ),
    cerr_stats = cms.untracked.PSet(
        optionalPSet = cms.untracked.bool(True),
        output = cms.untracked.string('cerr'),
        threshold = cms.untracked.string('WARNING')
    ),
    cout = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    debugModules = cms.untracked.vstring(),
    debugs = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    default = cms.untracked.PSet(

    ),
    destinations = cms.untracked.vstring('warnings', 
        'errors', 
        'infos', 
        'debugs', 
        'cout', 
        'cerr'),
    errors = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    fwkJobReports = cms.untracked.vstring('FrameworkJobReport'),
    infos = cms.untracked.PSet(
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        optionalPSet = cms.untracked.bool(True),
        placeholder = cms.untracked.bool(True)
    ),
    statistics = cms.untracked.vstring('cerr_stats'),
    suppressDebug = cms.untracked.vstring(),
    suppressInfo = cms.untracked.vstring(),
    suppressWarning = cms.untracked.vstring(),
    warnings = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    )
)


process.TFileService = cms.Service("TFileService",
    closeFileFast = cms.untracked.bool(True),
    fileName = cms.string('/afs/cern.ch/work/g/gkrintir/private/CMSSW_8_0_10/src/flashgg/Taggers/test/MVATHQTraining/test_diphodijet_training/output_GJet_Pt-40toInf_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8_numEvent1000_histos.root')
)


process.CSCGeometryESModule = cms.ESProducer("CSCGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    debugV = cms.untracked.bool(False),
    useCentreTIOffsets = cms.bool(False),
    useDDD = cms.bool(False),
    useGangedStripsInME1a = cms.bool(True),
    useOnlyWiresInME1a = cms.bool(False),
    useRealWireGeometry = cms.bool(True)
)


process.CaloGeometryBuilder = cms.ESProducer("CaloGeometryBuilder",
    SelectedCalos = cms.vstring('HCAL', 
        'ZDC', 
        'CASTOR', 
        'EcalBarrel', 
        'EcalEndcap', 
        'EcalPreshower', 
        'TOWER')
)


process.CaloTopologyBuilder = cms.ESProducer("CaloTopologyBuilder")


process.CaloTowerGeometryFromDBEP = cms.ESProducer("CaloTowerGeometryFromDBEP",
    applyAlignment = cms.bool(False),
    hcalTopologyConstants = cms.PSet(
        maxDepthHB = cms.int32(2),
        maxDepthHE = cms.int32(3),
        mode = cms.string('HcalTopologyMode::LHC')
    )
)


process.CaloTowerTopologyEP = cms.ESProducer("CaloTowerTopologyEP")


process.CastorDbProducer = cms.ESProducer("CastorDbProducer")


process.CastorGeometryFromDBEP = cms.ESProducer("CastorGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.DTGeometryESModule = cms.ESProducer("DTGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    fromDDD = cms.bool(False)
)


process.EcalBarrelGeometryFromDBEP = cms.ESProducer("EcalBarrelGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalElectronicsMappingBuilder = cms.ESProducer("EcalElectronicsMappingBuilder")


process.EcalEndcapGeometryFromDBEP = cms.ESProducer("EcalEndcapGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalLaserCorrectionService = cms.ESProducer("EcalLaserCorrectionService")


process.EcalPreshowerGeometryFromDBEP = cms.ESProducer("EcalPreshowerGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalTrigTowerConstituentsMapBuilder = cms.ESProducer("EcalTrigTowerConstituentsMapBuilder",
    MapFile = cms.untracked.string('Geometry/EcalMapping/data/EndCap_TTMap.txt')
)


process.GlobalTrackingGeometryESProducer = cms.ESProducer("GlobalTrackingGeometryESProducer")


process.HcalAlignmentEP = cms.ESProducer("HcalAlignmentEP")


process.HcalGeometryFromDBEP = cms.ESProducer("HcalGeometryFromDBEP",
    applyAlignment = cms.bool(True),
    hcalTopologyConstants = cms.PSet(
        maxDepthHB = cms.int32(2),
        maxDepthHE = cms.int32(3),
        mode = cms.string('HcalTopologyMode::LHC')
    )
)


process.MuonDetLayerGeometryESProducer = cms.ESProducer("MuonDetLayerGeometryESProducer")


process.MuonNumberingInitialization = cms.ESProducer("MuonNumberingInitialization")


process.ParabolicParametrizedMagneticFieldProducer = cms.ESProducer("AutoParametrizedMagneticFieldProducer",
    label = cms.untracked.string('ParabolicMf'),
    valueOverride = cms.int32(-1),
    version = cms.string('Parabolic')
)


process.RPCGeometryESModule = cms.ESProducer("RPCGeometryESModule",
    compatibiltyWith11 = cms.untracked.bool(True),
    useDDD = cms.untracked.bool(False)
)


process.SiStripRecHitMatcherESProducer = cms.ESProducer("SiStripRecHitMatcherESProducer",
    ComponentName = cms.string('StandardMatcher'),
    NSigmaInside = cms.double(3.0),
    PreFilter = cms.bool(False)
)


process.StripCPEfromTrackAngleESProducer = cms.ESProducer("StripCPEESProducer",
    ComponentName = cms.string('StripCPEfromTrackAngle'),
    ComponentType = cms.string('StripCPEfromTrackAngle'),
    parameters = cms.PSet(
        mLC_P0 = cms.double(-0.326),
        mLC_P1 = cms.double(0.618),
        mLC_P2 = cms.double(0.3),
        mTEC_P0 = cms.double(-1.885),
        mTEC_P1 = cms.double(0.471),
        mTIB_P0 = cms.double(-0.742),
        mTIB_P1 = cms.double(0.202),
        mTID_P0 = cms.double(-1.427),
        mTID_P1 = cms.double(0.433),
        mTOB_P0 = cms.double(-1.026),
        mTOB_P1 = cms.double(0.253),
        maxChgOneMIP = cms.double(6000.0),
        useLegacyError = cms.bool(False)
    )
)


process.TrackerRecoGeometryESProducer = cms.ESProducer("TrackerRecoGeometryESProducer")


process.VolumeBasedMagneticFieldESProducer = cms.ESProducer("VolumeBasedMagneticFieldESProducerFromDB",
    debugBuilder = cms.untracked.bool(False),
    label = cms.untracked.string(''),
    valueOverride = cms.int32(-1)
)


process.XMLFromDBSource = cms.ESProducer("XMLIdealGeometryESProducer",
    label = cms.string('Extended'),
    rootDDName = cms.string('cms:OCMS')
)


process.ZdcGeometryFromDBEP = cms.ESProducer("ZdcGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.fakeForIdealAlignment = cms.ESProducer("FakeAlignmentProducer",
    appendToDataLabel = cms.string('fakeForIdeal')
)


process.hcalDDDRecConstants = cms.ESProducer("HcalDDDRecConstantsESModule",
    appendToDataLabel = cms.string('')
)


process.hcalDDDSimConstants = cms.ESProducer("HcalDDDSimConstantsESModule",
    appendToDataLabel = cms.string('')
)


process.hcalTopologyIdeal = cms.ESProducer("HcalTopologyIdealEP",
    Exclude = cms.untracked.string(''),
    appendToDataLabel = cms.string('')
)


process.hcal_db_producer = cms.ESProducer("HcalDbProducer",
    dump = cms.untracked.vstring(''),
    file = cms.untracked.string('')
)


process.idealForDigiCSCGeometry = cms.ESProducer("CSCGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    debugV = cms.untracked.bool(False),
    useCentreTIOffsets = cms.bool(False),
    useDDD = cms.bool(False),
    useGangedStripsInME1a = cms.bool(True),
    useOnlyWiresInME1a = cms.bool(False),
    useRealWireGeometry = cms.bool(True)
)


process.idealForDigiDTGeometry = cms.ESProducer("DTGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    fromDDD = cms.bool(False)
)


process.idealForDigiTrackerGeometry = cms.ESProducer("TrackerDigiGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    fromDDD = cms.bool(False)
)


process.siPixelQualityESProducer = cms.ESProducer("SiPixelQualityESProducer",
    ListOfRecordToMerge = cms.VPSet(cms.PSet(
        record = cms.string('SiPixelQualityFromDbRcd'),
        tag = cms.string('')
    ), 
        cms.PSet(
            record = cms.string('SiPixelDetVOffRcd'),
            tag = cms.string('')
        ))
)


process.siStripBackPlaneCorrectionDepESProducer = cms.ESProducer("SiStripBackPlaneCorrectionDepESProducer",
    BackPlaneCorrectionDeconvMode = cms.PSet(
        label = cms.untracked.string('deconvolution'),
        record = cms.string('SiStripBackPlaneCorrectionRcd')
    ),
    BackPlaneCorrectionPeakMode = cms.PSet(
        label = cms.untracked.string('peak'),
        record = cms.string('SiStripBackPlaneCorrectionRcd')
    ),
    LatencyRecord = cms.PSet(
        label = cms.untracked.string(''),
        record = cms.string('SiStripLatencyRcd')
    )
)


process.siStripGainESProducer = cms.ESProducer("SiStripGainESProducer",
    APVGain = cms.VPSet(cms.PSet(
        Label = cms.untracked.string(''),
        NormalizationFactor = cms.untracked.double(1.0),
        Record = cms.string('SiStripApvGainRcd')
    ), 
        cms.PSet(
            Label = cms.untracked.string(''),
            NormalizationFactor = cms.untracked.double(1.0),
            Record = cms.string('SiStripApvGain2Rcd')
        )),
    AutomaticNormalization = cms.bool(False),
    appendToDataLabel = cms.string(''),
    printDebug = cms.untracked.bool(False)
)


process.siStripLorentzAngleDepESProducer = cms.ESProducer("SiStripLorentzAngleDepESProducer",
    LatencyRecord = cms.PSet(
        label = cms.untracked.string(''),
        record = cms.string('SiStripLatencyRcd')
    ),
    LorentzAngleDeconvMode = cms.PSet(
        label = cms.untracked.string('deconvolution'),
        record = cms.string('SiStripLorentzAngleRcd')
    ),
    LorentzAnglePeakMode = cms.PSet(
        label = cms.untracked.string('peak'),
        record = cms.string('SiStripLorentzAngleRcd')
    )
)


process.siStripQualityESProducer = cms.ESProducer("SiStripQualityESProducer",
    ListOfRecordToMerge = cms.VPSet(cms.PSet(
        record = cms.string('SiStripDetVOffRcd'),
        tag = cms.string('')
    ), 
        cms.PSet(
            record = cms.string('SiStripDetCablingRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('RunInfoRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadChannelRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadFiberRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadModuleRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadStripRcd'),
            tag = cms.string('')
        )),
    PrintDebugOutput = cms.bool(False),
    ReduceGranularity = cms.bool(False),
    ThresholdForReducedGranularity = cms.double(0.3),
    UseEmptyRunInfo = cms.bool(False),
    appendToDataLabel = cms.string('')
)


process.sistripconn = cms.ESProducer("SiStripConnectivity")


process.stripCPEESProducer = cms.ESProducer("StripCPEESProducer",
    ComponentName = cms.string('stripCPE'),
    ComponentType = cms.string('SimpleStripCPE'),
    parameters = cms.PSet(

    )
)


process.trackerGeometryDB = cms.ESProducer("TrackerDigiGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    fromDDD = cms.bool(False)
)


process.trackerNumberingGeometryDB = cms.ESProducer("TrackerGeometricDetESModule",
    appendToDataLabel = cms.string(''),
    fromDDD = cms.bool(False)
)


process.trackerTopology = cms.ESProducer("TrackerTopologyEP",
    appendToDataLabel = cms.string('')
)


process.GlobalTag = cms.ESSource("PoolDBESSource",
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        messageLevel = cms.untracked.int32(0),
        security = cms.untracked.string('')
    ),
    DumpStat = cms.untracked.bool(False),
    ReconnectEachRun = cms.untracked.bool(False),
    RefreshAlways = cms.untracked.bool(False),
    RefreshEachRun = cms.untracked.bool(False),
    RefreshOpenIOVs = cms.untracked.bool(False),
    connect = cms.string('frontier://FrontierProd/CMS_CONDITIONS'),
    globaltag = cms.string('80X_mcRun2_asymptotic_v14'),
    pfnPostfix = cms.untracked.string(''),
    pfnPrefix = cms.untracked.string(''),
    snapshotTime = cms.string(''),
    toGet = cms.VPSet()
)


process.eegeom = cms.ESSource("EmptyESSource",
    firstValid = cms.vuint32(1),
    iovIsRunNotTime = cms.bool(True),
    recordName = cms.string('EcalMappingRcd')
)


process.es_hardcode = cms.ESSource("HcalHardcodeCalibrations",
    GainWidthsForTrigPrims = cms.bool(False),
    HERecalibration = cms.bool(False),
    HEreCalibCutoff = cms.double(20.0),
    HFRecalibration = cms.bool(False),
    iLumi = cms.double(-1.0),
    testHFQIE10 = cms.bool(False),
    toGet = cms.untracked.vstring('GainWidths')
)


process.prefer("es_hardcode")

